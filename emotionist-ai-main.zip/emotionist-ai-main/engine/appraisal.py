import random
from entity.entity import Entity


# Emotion transition rules from emotionTransitions research data.
# Format: (from_emotion, condition_fn, to_emotion, probability)
TRANSITION_RULES: list[tuple] = [
    # Fear -> Distress (prolonged, uncertain fear curdles into distress)
    ("Fear", lambda e: e.is_active and e.time_active > 3, "Distress", 0.75),
    # Shame -> Anger (blame externalized)
    ("Shame", lambda e: e.is_active and e.intensity > 0.4, "Anger", 0.60),
    # Shame -> Sadness (internalized + chronic)
    ("Shame", lambda e: e.is_active and e.time_active > 5, "Sadness", 0.55),
    # Anger -> Guilt (harm caused to liked agent)
    ("Anger", lambda e: e.is_active and e.intensity > 0.6, "Guilt", 0.50),
    # Distress -> Sadness (coping failed + time)
    ("Distress", lambda e: e.is_active and e.time_active > 4, "Sadness", 0.80),
    # Hope -> Anticipation (likelihood increases)
    ("Hope", lambda e: e.is_active and e.intensity > 0.5, "Anticipation", 0.70),
    # Disappointment -> Resentment (other-agency)
    ("Disappointment", lambda e: e.is_active and e.intensity > 0.4, "Resentment", 0.55),
    # Joy -> Gratitude (other-agency identified)
    ("Joy", lambda e: e.is_active and e.intensity > 0.5, "Gratitude", 0.65),
]

# Fraction of the source emotion's intensity carried over to the target emotion
# when a transition fires.
TRANSITION_CARRY = 0.3


REACTIVITY = {
    "neurotic":  1.4,   # hits harder, spikes higher
    "average":   1.0,
    "resilient": 0.75,  # lower peak, but fades faster too
}


class OCCAppraisalEngine:
    """Maps structured appraisal events to emotion intensity deltas using OCC rules."""

    # -- De-escalation / damping (flaw fix: emotions too sticky, no fast recovery) --
    # Reassuring input actively *soothes* active negative emotions instead of only
    # adding positive ones and waiting for slow decay. Kept partial + capped so it's
    # earned: one nice line after something horrible won't erase real anger, and a
    # fresh hostile message still spikes normally.
    DAMPEN_EVENTS = {"compliment", "good_news", "agreement", "achievement", "praise_of_other"}
    SOOTHE_TARGETS = ("Anger", "Distress", "Fear", "Reproach", "Resentment",
                      "Shame", "Hate", "Disgust", "Contempt")
    DAMP_SCALE = 0.45        # how much a full-severity reassurance soothes
    MAX_SOOTHE_FRAC = 0.5    # never cut a given emotion by more than half in one turn

    def _apply_damping(self, et: str, sev: float, entity: Entity, deltas: dict) -> None:
        """Subtract a bounded amount from active negative emotions on reassuring input.
        Inverse-scaled by reactivity: neurotic agents calm slower, resilient faster."""
        if et not in self.DAMPEN_EVENTS:
            return
        soothe = (sev * self.DAMP_SCALE) / max(0.6, entity.reactivity)
        for name in self.SOOTHE_TARGETS:
            emo = entity.emotions.get(name)
            if emo and emo.is_active:
                reduction = min(emo.intensity * self.MAX_SOOTHE_FRAC, soothe)
                deltas[name] = deltas.get(name, 0.0) - reduction

    def compute_deltas(
        self, event: dict, entity: Entity, witness_event: dict | None = None
    ) -> dict[str, float]:
        """
        Returns a dict of {emotion_name: delta} to apply to the entity.
        event keys: event_type, severity, directed_at_self, intentional

        witness_event: the appraisal event the *sender* experienced receiving the
        previous message (i.e. what this agent just watched happen to the other
        agent). Used to generate empathic / vicarious emotion deltas.
        """
        et = event.get("event_type", "neutral")
        sev = float(event.get("severity", 0.2))
        self_directed = bool(event.get("directed_at_self", False))
        intentional = bool(event.get("intentional", False))

        deltas: dict[str, float] = {}

        if et == "compliment":
            if self_directed:
                deltas["Pride"] = sev * 0.8
                deltas["Joy"] = sev * 0.6
            else:
                deltas["Admiration"] = sev * 0.7
                deltas["HappyFor"] = sev * 0.4

        elif et == "insult":
            if self_directed and intentional:
                # Compound Anger = Reproach + Distress
                deltas["Reproach"] = sev * 0.7
                deltas["Distress"] = sev * 0.6
                deltas["Anger"] = sev * 0.9
            elif self_directed:
                deltas["Distress"] = sev * 0.7
                deltas["Shame"] = sev * 0.4
            else:
                deltas["Reproach"] = sev * 0.5

        elif et == "threat":
            if self_directed:
                deltas["Fear"] = sev * 0.9
                deltas["Distress"] = sev * 0.4
            else:
                deltas["Fear"] = sev * 0.5

        elif et == "good_news":
            if self_directed:
                deltas["Joy"] = sev * 0.9
                deltas["Satisfaction"] = sev * 0.5
            else:
                deltas["HappyFor"] = sev * 0.6
                deltas["Hope"] = sev * 0.3

        elif et == "bad_news":
            if self_directed:
                deltas["Distress"] = sev * 0.9
                deltas["Fear"] = sev * 0.4
            else:
                deltas["Pity"] = sev * 0.5
                deltas["Distress"] = sev * 0.3

        elif et == "achievement":
            if self_directed:
                # Gratification = Pride + Joy (own praiseworthy action)
                deltas["Pride"] = sev * 0.8
                deltas["Joy"] = sev * 0.7
                deltas["Gratification"] = sev * 0.9
            else:
                deltas["Admiration"] = sev * 0.7

        elif et == "failure":
            if self_directed:
                # Remorse = Shame + Distress
                deltas["Shame"] = sev * 0.7
                deltas["Distress"] = sev * 0.6
                deltas["Remorse"] = sev * 0.5
            else:
                deltas["Pity"] = sev * 0.5

        elif et == "agreement":
            deltas["Joy"] = sev * 0.5
            deltas["Trust"] = sev * 0.6
            deltas["Satisfaction"] = sev * 0.3

        elif et == "disagreement":
            deltas["Distress"] = sev * 0.5
            if intentional:
                deltas["Reproach"] = sev * 0.4
                deltas["Resentment"] = sev * 0.3

        elif et == "praise_of_other":
            deltas["Admiration"] = sev * 0.6
            deltas["HappyFor"] = sev * 0.3

        elif et == "blame_of_other":
            deltas["Reproach"] = sev * 0.6
            if self_directed:
                # other's blameworthy action caused harm to self -> Anger
                deltas["Anger"] = sev * 0.7

        elif et == "neutral":
            # Rumination / persistence injection: grief and fear sustain themselves
            # without needing a new trigger. Quiet turns in a grief scenario get
            # tagged neutral - this prevents the emotional state from starving.
            distress = entity.emotions.get("Distress")
            fear = entity.emotions.get("Fear")
            sadness = entity.emotions.get("Sadness")
            if distress and distress.intensity > 0.5:
                deltas["Distress"] = 0.05
            if fear and fear.intensity > 0.4:
                deltas["Fear"] = 0.03
            if sadness and sadness.intensity > 0.4:
                deltas["Sadness"] = 0.04

        # -- Witness / empathy track -------------------------------------------
        # Apply vicarious emotion deltas from what this agent *witnessed* the
        # other agent experience, regardless of what the other agent said.
        # Scaled at ~0.55 of the witnessed severity so witnessing < experiencing.
        if witness_event:
            wet = witness_event.get("event_type", "neutral")
            wsev = float(witness_event.get("severity", 0.0))
            w_self = bool(witness_event.get("directed_at_self", False))
            w_intent = bool(witness_event.get("intentional", False))
            ws = wsev * 0.55  # witness scale factor

            # Don't fire witness Pity if this agent is already the primary sufferer
            # of the same class of event - the fired agent doesn't pity the person
            # offering support.
            agent_is_sufferer = (
                et in ("bad_news", "failure", "threat") and
                self_directed and
                entity.emotions.get("Distress") and
                entity.emotions["Distress"].intensity > 0.6
            )

            if w_self and wet in ("bad_news", "failure", "threat") and not agent_is_sufferer:
                # Witnessing someone suffer bad news / failure / threat
                deltas["Pity"] = deltas.get("Pity", 0) + ws * 0.9
                deltas["Distress"] = deltas.get("Distress", 0) + ws * 0.5
                # Guilt: supporter's instinct of "I should be doing more"
                deltas["Guilt"] = deltas.get("Guilt", 0) + ws * 0.20

            elif w_self and wet == "insult" and w_intent:
                # Witnessing someone get insulted - protective reproach
                deltas["Pity"] = deltas.get("Pity", 0) + ws * 0.7
                deltas["Reproach"] = deltas.get("Reproach", 0) + ws * 0.5

            elif w_self and wet in ("good_news", "achievement"):
                # Witnessing someone receive good news / succeed
                deltas["HappyFor"] = deltas.get("HappyFor", 0) + ws * 0.8
                deltas["Joy"] = deltas.get("Joy", 0) + ws * 0.3

            elif w_self and wet == "compliment":
                deltas["HappyFor"] = deltas.get("HappyFor", 0) + ws * 0.6

        scaled = {name: delta * entity.reactivity for name, delta in deltas.items()}
        # Damping is computed on real current intensities, so apply it *after* the
        # reactivity scaling (and with its own inverse-reactivity weighting).
        self._apply_damping(et, sev, entity, scaled)
        return scaled

    def apply_transitions(self, entity: Entity):
        """Check and probabilistically fire emotion transitions."""
        for from_name, condition_fn, to_name, prob in TRANSITION_RULES:
            source = entity.emotions.get(from_name)
            target = entity.emotions.get(to_name)
            if source is None or target is None:
                continue
            if condition_fn(source) and random.random() < prob:
                target.activate(source.intensity * TRANSITION_CARRY)


if __name__ == "__main__":
    # ponytail: self-check - de-escalation is real, partial, and not manipulable.
    eng = OCCAppraisalEngine()
    ent = Entity("Test", "average")
    insult = {"event_type": "insult", "severity": 0.85, "directed_at_self": True, "intentional": True}
    reassure = {"event_type": "agreement", "severity": 0.8, "directed_at_self": True, "intentional": False}

    ent.apply_deltas(eng.compute_deltas(insult, ent))
    spiked = ent.emotions["Anger"].intensity
    assert spiked > 0.4, f"insult should spike anger, got {spiked}"

    ent.apply_deltas(eng.compute_deltas(reassure, ent))
    soothed = ent.emotions["Anger"].intensity
    assert soothed < spiked, "reassurance should reduce anger"
    assert soothed > 0.05, f"one nice line must NOT erase real anger, got {soothed}"

    ent.apply_deltas(eng.compute_deltas(insult, ent))
    assert ent.emotions["Anger"].intensity > soothed, "a fresh insult must re-spike anger"

    print(f"OK - anger spiked {spiked:.2f} -> soothed {soothed:.2f} -> re-spiked "
          f"{ent.emotions['Anger'].intensity:.2f} (earned calm, still reactive)")
